//
//  InterfaceController.swift
//  PizzAppW Extension
//
//  Created by Raul Guerra Hernandez on 11/24/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    var miPizza : Pizza?

    
    
    @IBAction func buttonQuieroPizza() {
        miPizza = Pizza()
        miPizza?.tamano = 0
        pushController(withName: "identificadorTamano", context: miPizza)
    }
    
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
