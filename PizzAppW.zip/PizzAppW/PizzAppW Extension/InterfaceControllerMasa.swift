//
//  InterfaceControllerMasa.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceControllerMasa: WKInterfaceController {
    
    
    var miPizza = Pizza()
    
    var lista   : [String] = Masa
    
    var masaPrevia = 0

    
    @IBOutlet var sliderMasaOutlet: WKInterfaceSlider!
    
    @IBOutlet var etiquetaMasa: WKInterfaceLabel!
    
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        miPizza = context as! Pizza
        
        if miPizza.masa != nil{
            masaPrevia = miPizza.masa!
        }
        
        etiquetaMasa.setText(lista[masaPrevia])
        
        let numElementos = lista.count
        sliderMasaOutlet.setNumberOfSteps(numElementos-1)
        sliderMasaOutlet.setValue(Float(masaPrevia))
    }

    
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    
    @IBAction func sliderMasaAction(_ value: Float) {
        masaPrevia = Int(value)
        etiquetaMasa.setText(lista[Int(value)])
    }
    
    
    
    @IBAction func buttonSiguiente() {
        miPizza.masa = masaPrevia
        pushController(withName: "identificadorQueso", context: miPizza)
    }

}
