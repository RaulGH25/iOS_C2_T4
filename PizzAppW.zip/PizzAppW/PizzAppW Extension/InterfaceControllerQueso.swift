//
//  InterfaceControllerQueso.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceControllerQueso: WKInterfaceController {
    
    var miPizza = Pizza()
    
    var lista   : [String] = Queso
    
    var quesoPrevio = 0
    
    
    
    @IBOutlet var etiquetaQueso: WKInterfaceLabel!
    
    @IBOutlet var sliderQuesoOutlet: WKInterfaceSlider!
    
    
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        miPizza = context as! Pizza
        
        if miPizza.queso != nil{
            quesoPrevio = miPizza.queso!
        }
        
        etiquetaQueso.setText(lista[quesoPrevio])
        
        let numElementos = lista.count
        sliderQuesoOutlet.setNumberOfSteps(numElementos-1)
        sliderQuesoOutlet.setValue(Float(quesoPrevio))
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    
    
    @IBAction func sliderQuesoAction(_ value: Float) {
        quesoPrevio = Int(value)
        etiquetaQueso.setText(lista[Int(value)])
    }
    
    

    @IBAction func buttonAction() {
        miPizza.queso = quesoPrevio
        pushController(withName: "identificadorIngredientes", context: miPizza)
    }
    

}
