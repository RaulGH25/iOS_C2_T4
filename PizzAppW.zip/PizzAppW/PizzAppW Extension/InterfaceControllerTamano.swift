//
//  InterfaceControllerTamano.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceControllerTamano: WKInterfaceController {

    var miPizza = Pizza()
    
    var lista   : [String] = Tamano
    
    var tamanoPrevio = 0
    
    
    @IBOutlet var sliderTamañoOutlet: WKInterfaceSlider!
    
    @IBOutlet var etiquetaTamaño: WKInterfaceLabel!
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        miPizza = context as! Pizza
        
        if miPizza.tamano != nil{
            tamanoPrevio = miPizza.tamano!
        }
        
        etiquetaTamaño.setText(lista[tamanoPrevio])
        
        let numElementos = lista.count
        sliderTamañoOutlet.setNumberOfSteps(numElementos-1)
        sliderTamañoOutlet.setValue(Float(tamanoPrevio))
    }
    

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    @IBAction func sliderTamañoAccion(_ value: Float) {
        tamanoPrevio = Int(value)
        etiquetaTamaño.setText(lista[Int(value)])
    }
    
    
    @IBAction func buttonSiguiente() {
        miPizza.tamano = tamanoPrevio
        pushController(withName: "identificadorMasa", context: miPizza)
    }
    

}
