//
//  DataModelW.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import Foundation


class Pizza {
    
    var isAllSet        : Bool      = false
    var tamano          : Int?      = nil
    var masa            : Int?      = nil
    var queso           : Int?      = nil
    var ingredientes    : [Int]     = [0,0,0,0,0,0,0,0,0]
    
}


public let Tamano       : [String] = ["Pequeña", "Mediana", "Grande"]

public let Masa         : [String] = ["Delgada", "Crujiente", "Gruesa"]

public let Queso        : [String] = ["Mozarela", "Cheddar", "Parmesano", "Sin queso"]

public let Ingredientes : [String] = ["Jamón", "Pepperoni", "Pavo", "Salchicha", "Aceituna", "Cebolla", "Pimiento", "Piña", "Anchoa"]
