//
//  CustomRowController.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit

class CustomRowController: WKInterfaceController {

    @IBOutlet var nameLabel: WKInterfaceLabel!

}


