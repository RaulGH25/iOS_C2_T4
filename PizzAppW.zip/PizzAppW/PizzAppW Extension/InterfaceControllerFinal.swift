//
//  InterfaceControllerFinal.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceControllerFinal: WKInterfaceController {
    
    
    var miPizza = Pizza()
    
    var listaTamano         : [String] = Tamano
    var listaMasa           : [String] = Masa
    var listaQueso          : [String] = Queso
    var listaIngredientes   : [String] = Ingredientes
    
    
    @IBOutlet var labelTamano: WKInterfaceLabel!
    
    @IBOutlet var labelMasa: WKInterfaceLabel!
    
    @IBOutlet var labelQueso: WKInterfaceLabel!
    
    @IBOutlet var labelIngredientes: WKInterfaceLabel!
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        miPizza = context as! Pizza
        
        labelTamano.setText("\(listaTamano[miPizza.tamano!])")
        labelMasa.setText("\(listaMasa[miPizza.masa!])")
        labelQueso.setText("\(listaQueso[miPizza.queso!])")
        
        print("tamaño: \(listaTamano[miPizza.tamano!])")
        print("masa: \(listaMasa[miPizza.masa!])")
        print("queso: \(listaQueso[miPizza.queso!])")
        
        for i in 0...listaIngredientes.count-1{
            if miPizza.ingredientes[i]==1{
                print("ingrediente: \(listaIngredientes[i])")
            }
        }
        
        let numIngredientes = contarIngredientes(vector: miPizza.ingredientes)
        let contador = 0
        
        var textoIngredientes : String = " "
        
        for i in 0...listaIngredientes.count-1{
            if miPizza.ingredientes[i]==1{
                if contador<numIngredientes-1{
                    textoIngredientes += "\(listaIngredientes[i]) \n"
                }else{
                    textoIngredientes += "\(listaIngredientes[i])"
                }
            }
        }
        labelIngredientes.setText(textoIngredientes)

        
        
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    
    
    @IBAction func buttonSiguiente() {
        pushController(withName: "identificadorInicial", context: Pizza())
    }
    
    
    func contarIngredientes(vector : [Int]) -> Int{
        var contador = 0
        let num = vector.count
        for i in 0...num-1{
            contador += vector[i]
        }
        return contador
    }
    

}
