//
//  InterfaceControllerIngredientes.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/25/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceControllerIngredientes: WKInterfaceController {

    
    var miPizza = Pizza()
    
    var lista   : [String] = Ingredientes
    
    var numPrevio = 0
    
    var ingredientesPrevios : [Int] = [0]
    
    var elemento = 0
    
    
    
    @IBOutlet var etiquetaIngrediente: WKInterfaceLabel!
    
    @IBOutlet var etiquetaNumIngredientes: WKInterfaceLabel!
    
    @IBOutlet var slicerIngredientesOutlet: WKInterfaceSlider!
    
    @IBOutlet var buttonAñadirOutlet: WKInterfaceButton!
    
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        miPizza = context as! Pizza
        
        ingredientesPrevios = miPizza.ingredientes
        
        numPrevio = contarIngredientes(vector: ingredientesPrevios)
        etiquetaNumIngredientes.setText("\(numPrevio)")
        
        etiquetaIngrediente.setText(lista[0])
        
        if ingredientesPrevios[0] == 0{
            buttonAñadirOutlet.setTitle("Añadir")
        }else{
            buttonAñadirOutlet.setTitle("Quitar")
        }
        
        let numElementos = lista.count
        slicerIngredientesOutlet.setNumberOfSteps(numElementos-1)
        slicerIngredientesOutlet.setValue(Float(0))
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    
    @IBAction func slicerIngredientesAction(_ value: Float) {
        
        elemento = Int(value)
        etiquetaIngrediente.setText(lista[elemento])
        if ingredientesPrevios[elemento] == 0{
            buttonAñadirOutlet.setTitle("Añadir")
        }else{
            buttonAñadirOutlet.setTitle("Quitar")
        }
        
    }
    
    
    @IBAction func buttonAñadirAction() {
        if ingredientesPrevios[elemento] == 0{
            if numPrevio<5{
                ingredientesPrevios[elemento] = 1
                numPrevio = numPrevio + 1
                buttonAñadirOutlet.setTitle("Quitar")
            }
        }else{
            ingredientesPrevios[elemento] = 0
            numPrevio = numPrevio + -1
            buttonAñadirOutlet.setTitle("Añadir")
        }
        etiquetaNumIngredientes.setText("\(numPrevio)")
    }

    
    @IBAction func buttonSiguiente() {
        if numPrevio>0 {
            miPizza.ingredientes = ingredientesPrevios
            pushController(withName: "identificadorFinal", context: miPizza)
        }
    }
    
    
    
    func contarIngredientes(vector : [Int]) -> Int{
        var contador = 0
        let num = vector.count
        for i in 0...num-1{
            contador += vector[i]
        }
        return contador
    }

    
}



