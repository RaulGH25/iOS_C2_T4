//
//  ViewControllerTamano.swift
//  PizzApp
//
//  Created by Raul Guerra Hernandez on 11/17/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class ViewControllerTamano: UIViewController,  UITableViewDelegate, UITableViewDataSource {

    
    var miPizza : Pizza = Pizza()
    var allSet  : Bool = false
    var lista   : [String] = Tamano
    
    var tamanoPrevioIndex       : Int = 0;
    
    @IBOutlet weak var myTable: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.myTable.dataSource = self
        self.myTable.delegate = self
    }
    
       
    override func viewWillAppear(_ animated: Bool) {
        myTable.contentInset = UIEdgeInsetsMake(0,0,0,0);
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // Revisar si hay algun tamaño seleccionado previamente
        if self.miPizza.tamano != nil{
            let tamanoPrevioIndex = self.miPizza.tamano
            if let cell = myTable.cellForRow(at: NSIndexPath(row: tamanoPrevioIndex!, section: 0) as IndexPath) {
                cell.accessoryType = .checkmark
            }
            self.tamanoPrevioIndex = tamanoPrevioIndex!
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    @IBAction func buttonTamano(_ sender: AnyObject) {
        self.allSet = self.miPizza.isAllSet
        if allSet == false{
            // Se revisa que haya algún tamaño seleccionado
            if self.miPizza.tamano != nil{
                // Se hace el segue a la siguiente vista para decidir la masa de la pizza
                self.performSegue(withIdentifier: "segueTamano", sender: self)
            }
        }else{
            // Se hace el segue a la ultima vista
            self.performSegue(withIdentifier: "segueTamanoAllSet", sender: self)
        }
    }
    
    
    
    // El prepare for segue es necesario para pasar el objeto pizza
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if self.allSet == false{
            let nextView = segue.destination as! ViewControllerMasa
            nextView.miPizza = self.miPizza;
        }else{
            let nextView = segue.destination as! ViewControllerFinal
            nextView.miPizza = self.miPizza;
        }
    }
    
    
    // TableView:
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lista.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let element = lista[indexPath.row]
        
        // Instantiate a cell
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "ElementCell")
        
        // Adding the right informations
        cell.textLabel?.text = element;
        
        // Returning the cell
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Guardar el indice del elemento marcado
        let tamanoActualIndex  = indexPath.row
        //let tamanoActual = (lista[tamanoActualIndex])
        self.miPizza.tamano = tamanoActualIndex;
        
        // Mostrar y quitar los ticks
        
        let tamanoPrevioIndex = self.tamanoPrevioIndex
        if let cell = tableView.cellForRow(at: NSIndexPath(row: tamanoPrevioIndex, section: 0) as IndexPath){
            cell.accessoryType = .none
        }
        
        if let cell = tableView.cellForRow(at: indexPath) {
            cell.accessoryType = .checkmark
        }
        
        self.tamanoPrevioIndex = tamanoActualIndex
    }
    

}
